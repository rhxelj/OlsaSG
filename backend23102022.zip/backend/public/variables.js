var dirpresupdocumento = '/home/sandra/Documentos/OLSAFrecuentes/PresupSistema/';
// var caminoynombrearch = ' /home/sandra/SistOLSA/OlsaSG/build/static/media/basics.pdf';
var caminoynombrearch = ' /home/sandra/SistOLSA/OlsaSG/src/components/Main/pages/Presupuesto/static/media/basics.pdf';

module.exports = {
    dirpresupdocumento,
    caminoynombrearch
}
